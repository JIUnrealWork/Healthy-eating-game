using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
   
    public float playerSpeed = 200;
    private Vector2 hMovement = new Vector2(0f, 0f);
    private GameController gameController;
    // Start is called before the first frame update
    void Start()
    {
        gameController = GameObject.Find("GameController").GetComponent<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        hMovement = new Vector2(Input.GetAxisRaw("Horizontal"), 0);// sets horizontal moment based on key pressed

    }

    void FixedUpdate()  // update locked to Physics Engine
    {
        GetComponent<Rigidbody2D>().velocity =
            hMovement * playerSpeed * Time.fixedDeltaTime;
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.name.StartsWith("GoodFood"))
        {
            gameController.IncrementScoreUp();
            playerSpeed = playerSpeed + 20f;
            Debug.Log("This works");
        }
        
        if (other.gameObject.name.StartsWith("BadFood"))
        {
            gameController.LoseALife();
            playerSpeed = 150;
        }
    }
}
