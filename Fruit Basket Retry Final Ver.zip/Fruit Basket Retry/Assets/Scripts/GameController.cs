using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{


    public AudioClip fallSound;
    private AudioSource myAudioSource;

    public TMP_Text HighScoreText;
    public static int HighScore;
    public GameObject BadFood;
    public GameObject GoodFood;
    public int playerScore;
    public int playerLives = 3;
    bool playerLose;
    public TMP_Text ScoreText;
    public GameObject Player;
    public TMP_Text LivesText;
    // Start is called before the first frame update
    void Start()
    {

        playerLives = 3;
        playerScore = 0;
        playerLose = false;
        InvokeRepeating("SpawnGoodFood", 1f, 2f);
        InvokeRepeating("SpawnBadFood", 1f, 1f);
    }
    void SpawnGoodFood() // saying what the custom event does
    {
        float X = (7f); // asigns a random value between -7 and 7 to randomX
        float randomY = Random.Range(-3.5f, 2.5f);// asigns a random value between -3.5 and 2.5 to randomY
        Vector3 randomPosition = new Vector3(randomY, X, -1f); // the vector 3 has a custom event randomPosition, the randomPosition makes it a new Vector3 with the two random values and a -1
        Instantiate(GoodFood, randomPosition, Quaternion.identity); //the instantiate calls the objectToSpawn value and the randomPosition value which tells the location of the X and Y axis

    }
    void SpawnBadFood() // saying what the custom event does
    {
        float X = (7f); // asigns a random value between -7 and 7 to randomX
        float randomY = Random.Range(-3.5f, 2.5f);// asigns a random value between -3.5 and 2.5 to randomY
        Vector3 randomPosition = new Vector3(randomY, X, -1f); // the vector 3 has a custom event randomPosition, the randomPosition makes it a new Vector3 with the two random values and a -1
        Instantiate(BadFood, randomPosition, Quaternion.identity); //the instantiate calls the objectToSpawn value and the randomPosition value which tells the location of the X and Y axis

    }
    // Update is called once per frame
    void Update()
    {
       ScoreText.text = playerScore.ToString("00");
       LivesText.text = playerLives.ToString("00");
       HighScoreText.text = HighScore.ToString("000");

        if (playerLives <= 0)
        {
            playerLose = true;

             if (playerLose == true)
             {
              SceneManager.LoadScene("GameOverScene");
             }
        }
        
      
    }

    public void IncrementScoreUp()
    {
        playerScore++ ; // adding one to itself, so adding one to the current player score
        UpdateHighScore();
        //Debug.Log(playerScore); // just shows you the score in the console since we dont have anything to update the score text yet.
        Debug.Log("this works");
    }

    public void LoseALife()
    {
        playerLives--; // decrease player lives by one

        Debug.Log("Lost a life bro");
    }

   public void UpdateHighScore()
   {
        Debug.Log("High score did update");
        if(playerScore > HighScore)
        {
            HighScore = playerScore;
        }
   }


}
